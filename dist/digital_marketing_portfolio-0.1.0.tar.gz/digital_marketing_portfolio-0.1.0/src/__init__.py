"""
Digital Marketing Portfolio Website
A modern portfolio website for digital marketing and SEO experts.
"""

__version__ = "0.1.0" 